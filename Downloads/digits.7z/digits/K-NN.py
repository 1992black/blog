# -*-coding:utf-8-*-

import os
import time
import operator
from numpy import *

TRAINDIR = os.getcwd() + '\\trainingDigits\\'
TESTDIR = os.getcwd() + '\\testDigits\\'

def createDataSet():
    group = array([[1.0, 1.1], [1.0, 1.0], [0, 0], [0, 0.1]])
    labels = ['A', 'A', 'B', 'B']
    return group, labels

def img2vector(filename):
    returnVect = zeros(1024)    #创建一个1024长度的list因为每个数字文件都是32*32的矩阵
    fr = open(filename, 'r')
    for i in range(32):
        lineStr = fr.readline()
        for j in range(32):
            returnVect[32 * i + j] = int(lineStr[j])
    
    return returnVect

def classify0(inX, dataSet, labels, k):
    dataSetSize = dataSet.shape[0]  #等同于len(dataSet)区别为当shape(1)时计算的是len(dataSet[0])
    diffMat = tile(inX, (dataSetSize, 1)) - dataSet     #复制inX为dataSetSize列, 1为每列出现一次, 2便复制两次
    sqDiffMat = diffMat ** 2
    sqDistances = sqDiffMat.sum(axis = 1)   #axis = 0为列求和, axis = 1为行求和
    sortedDisIndecies = sqDistances.argsort()   #返回值为从小到大排列后的下角标, 数组为numpy.zeros(n)所创建
    classCount = {}
    for i in range(k):
        voteIlabel = labels[sortedDisIndecies[i]]
        classCount[voteIlabel] = classCount.get(voteIlabel, 0) + 1
    
    sortedClassCount = sorted(classCount.iteritems(), key = operator.itemgetter(1), reverse = True) #reverse = True为从大到小排序
    
    return sortedClassCount[0][0]

def handwriteClassTest():
    t1 = time.time()
    hwLabels = []
    trainingFileList = os.listdir(TRAINDIR)
    m = len(trainingFileList)
    trainingMat = zeros((m, 1024))
    for i in range(m):
        fileNameStr = trainingFileList[i]
        fileStr = fileNameStr.split('.')[0]
        classNumStr = int(fileStr.split('_')[0])
        hwLabels.append(classNumStr)
        trainingMat[i, :] = img2vector(TRAINDIR + fileNameStr)
    testFileList = os.listdir(TESTDIR)
    errorCount = 0
    mTest = len(testFileList)
    
    for i in range(mTest):
        fileNameStr = testFileList[i]
        fileStr = fileNameStr.split('.')[0]
        classNumStr = int(fileStr.split('_')[0])
        vectorUnderTest = img2vector(TESTDIR + fileNameStr)
        classifierResult = classify0(vectorUnderTest, trainingMat, hwLabels, 3)
        #print "the classifier came back with: %d, the real answer is: %d" % (classifierResult, classNumStr)
        if(classifierResult != classNumStr):
            errorCount += 1;
    
    t2 = time.time()
    print 'time', t2 - t1
    print "the total number of errors is", errorCount
    print "the total error rate is:", 1.0 * errorCount / mTest

if __name__ == '__main__':
    handwriteClassTest()
    #group, labels = createDataSet()
    #print classify0([0, 0], group, labels, 3)
    
    
    
    
    
    
    
    
    
    
    
    
    