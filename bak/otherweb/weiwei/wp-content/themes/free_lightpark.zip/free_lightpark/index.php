<?php get_header(); 
 get_template_part( 'index/pic' );
 
get_template_part( 'index/full_bigpic' );
get_template_part( 'index/two' );


get_footer(); ?>
