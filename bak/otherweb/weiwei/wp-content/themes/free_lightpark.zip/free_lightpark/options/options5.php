<div class="modle">
<b>兼容手机和平板电脑的功能只有付费版本才能使用，查看付费版本介绍：<br /><br /><br />

<a target="_blank" href="http://www.themepark.com.cn/qjqywordpresszt.html"> http://www.themepark.com.cn/qjqywordpresszt.html</a></b>
<br /><br /><br />
付费版演示：<br /><br /><br /><a target="_blank" href="http://www.themepark.com.cn/demo/?themedemo=lightpark-yanshi"> http://www.themepark.com.cn/demo/?themedemo=lightpark-yanshi</a></b>

</div> 