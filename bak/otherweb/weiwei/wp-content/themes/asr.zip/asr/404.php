<?php get_header();?>
        <!---top--->
       <div class="net_banner">
    <?php echo "<p>".get_the_title()."</p>";?></div>
    
    <!----content--->
    <div class="content clearfloat">
	<div class="left fl">
        	<h3>CONTACT US</h3>
            <UL>
            	<li><a href="<?php echo get_bloginfo("url")?>/contact-us">Contact Us</a></li>
                <li><a href="<?php echo get_bloginfo("url")?>/feedback">Feedback</a></li>
           
            </UL>
        </div>
    	
  <div class="about">
        	<h2>page not found </h2>
            <div class="word" style="text-align:center; margin-top:40px;">
   	  			 <img src="<?php echo  get_bloginfo("template_url")?>/images/404.png" />
      				
     		</div>
        
      </div>
      
    
    
    </div>
	
        
        
<!---bg--->
      


<!---contact--->
<?php get_footer();?>