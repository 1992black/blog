<?php

return array(
    array(
            'name' => '网站右侧',
            'id' => 'gkwp-right',
            'before_widget' => '<div id="%1$s" class="widget well %2$s">',
            'after_widget' => "</div>",
            'before_title' => '<h3 class="right_title">',
            'after_title' => '</h3>',
            'default'=>'search,weiboShow,recent-comments,tag_cloud,recent-posts',
         )
);