        <!-- Sidebar -->
        <div id="sidebar">
            <?php
            if(!dynamic_sidebar('gkwp-right')){
                _e('右侧展示没有内容','gkwp');
            }
            ?>
        </div>
        <!-- /Sidebar -->